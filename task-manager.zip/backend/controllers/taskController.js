const Task = require('../models/taskModel');

// Create a new task
exports.createTask = async (req, res) => {
    const { title, description, dueDate, priority } = req.body;
    try {
        const newTask = new Task({ title, description, dueDate, priority });
        await newTask.save();
        res.status(201).json(newTask);
    } catch (err) {
        res.status(400).json({ message: 'Error creating task', error: err.message });
    }
};

// Get all tasks
exports.getTasks = async (req, res) => {
    try {
        const tasks = await Task.find();
        res.status(200).json(tasks);
    } catch (err) {
        res.status(400).json({ message: 'Error retrieving tasks', error: err.message });
    }
};

// Update task status
exports.updateTaskStatus = async (req, res) => {
    try {
        const { id, status } = req.params;
        const task = await Task.findByIdAndUpdate(id, { status }, { new: true });
        res.status(200).json(task);
    } catch (err) {
        res.status(400).json({ message: 'Error updating task', error: err.message });
    }
};

// Delete a task
exports.deleteTask = async (req, res) => {
    try {
        await Task.findByIdAndDelete(req.params.id);
        res.status(200).json({ message: 'Task deleted successfully' });
    } catch (err) {
        res.status(400).json({ message: 'Error deleting task', error: err.message });
    }
};
