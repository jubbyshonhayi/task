const createTaskButton = document.getElementById('createTask');
const taskList = document.getElementById('taskList');

// Fetch tasks from backend
async function getTasks() {
    const response = await fetch('http://localhost:5000/api/tasks');
    const tasks = await response.json();
    taskList.innerHTML = '';
    tasks.forEach(task => {
        taskList.innerHTML += `
            <div class="task">
                <h3>${task.title}</h3>
                <p>${task.description}</p>
                <p>Due Date: ${task.dueDate}</p>
                <p>Priority: ${task.priority}</p>
                <p>Status: ${task.status}</p>
            </div>
        `;
    });
}

// Create a new task
createTaskButton.addEventListener('click', async () => {
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const dueDate = document.getElementById('dueDate').value;
    const priority = document.getElementById('priority').value;

    const response = await fetch('http://localhost:5000/api/tasks', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title, description, dueDate, priority }),
    });

    const newTask = await response.json();
    getTasks(); // Refresh the task list
});

// Initial fetch of tasks
getTasks();
